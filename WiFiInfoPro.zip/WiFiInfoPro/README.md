# WiFi Info Pro

Android uchun zamonaviy Wi-Fi tarmoq skaneri va tahlil qiluvchi ilova. Material 3
dizayn, Jetpack Compose, Kotlin asosida qurilgan. O'zbek (asosiy), rus va ingliz
tillarini qo'llab-quvvatlaydi, tungi/kunduzgi rejim mavjud.

## Loyihani qanday ochish va build qilish

1. **Android Studio** (Koala yoki undan yangi versiya) o'rnating.
2. Ushbu papkani **File → Open** orqali Android Studio'da oching.
3. Studio Gradle Sync jarayonini avtomatik boshlaydi va `gradle-wrapper.jar`
   faylini (bu arxivda yo'q, chunki ikkilik fayl tarmoqdan yuklab olinishi kerak)
   o'zi yaratadi/yuklaydi. Agar so'ralsa, **"Gradle wrapper faylini yaratish"**
   taklifini tasdiqlang, yoki `gradle wrapper` buyrug'ini terminalda bajaring.
4. **Build → Make Project** yoki `Shift+F10` orqali ilovani ishga tushiring.
5. Haqiqiy qurilmada sinab ko'rish tavsiya etiladi — emulyatorlarda Wi-Fi
   skanerlash natijalari cheklangan yoki soxta bo'lishi mumkin.

> **Muhim:** Bu loyiha to'liq Kotlin/Compose manba kodi sifatida tayyorlangan.
> Uni ushbu suhbat muhitida kompilyatsiya qilish imkoni bo'lmadi, chunki bu yerda
> Android SDK/Gradle to'liq to'plami mavjud emas. Android Studio'da ochilganda
> standart Gradle sync orqali barcha bog'liqliklar (Compose, Navigation,
> osmdroid, Play Services Location, Accompanist) avtomatik yuklanadi.

## Asosiy imkoniyatlar

- **Real-vaqt skanerlash** — `WifiManager` orqali atrofdagi barcha tarmoqlarni aniqlash
- **To'liq texnik ma'lumot**: SSID, BSSID, signal (dBm/%), chastota, kanal,
  kanal kengligi, Wi-Fi standarti (a/b/g/n/ac/ax/be), xavfsizlik turi,
  taxminiy masofa, nazariy maksimal tezlik
- **MAC Vendor lookup** — mahalliy OUI jadvali orqali router ishlab
  chiqaruvchisini aniqlash (TP-Link, Xiaomi, Huawei, ASUS, MikroTik va h.k.)
- **Filtrlash va qidiruv** — SSID/BSSID/vendor bo'yicha, chastota diapazoni bo'yicha
- **Saralash** — signal kuchi, nom, kanal bo'yicha
- **Eng kuchli signal** belgilash (yulduzcha va ramka bilan)
- **Signal tarixi grafigi** — har bir tarmoq uchun vaqt bo'yicha RSSI o'zgarishi
- **Kanal bandligi grafigi** — 2.4 GHz va 5 GHz kanallar bo'yicha ustunli diagramma
- **Xarita** — GPS ruxsati bilan joriy joylashuv va yaqin atrofdagi tarmoqlar
  (taxminiy joylashuv doiralari; Android hech qanday routerning aniq GPS
  koordinatasini bermaydi — bu texnik jihatdan mumkin emas)
- **Tezlik testi** — internetga ulangan bo'lsa, ping/yuklab olish/yuklash tezligi
- **Dark/Light rejim** va tizim tiliga moslashuvchi interfeys (uz/ru/en)

## Texnik cheklovlar (Android xavfsizlik siyosati)

Quyidagi ma'lumotlar **hech qanday mobil ilova** (shu jumladan bu ilova) orqali
olinishi mumkin emas, chunki ular Android tizim API'larida umuman mavjud emas:

- Wi-Fi tarifi va internet paketi
- Kimning nomiga ro'yxatdan o'tgani (abonent ma'lumotlari)
- To'lov holati yoki muddat tugashi
- Provayderning ichki abonent bazasi

Bu ma'lumotlar faqat internet-provayder serverlarida saqlanadi va faqat
ularning shaxsiy kabinetlari yoki API'lari orqali olinishi mumkin — oddiy
Wi-Fi skaneri esa faqat `ScanResult` orqali translyatsiya qilingan radio
signalidan ma'lumot o'qiydi.

Shuningdek MAC manzil orqali ishlab chiqaruvchini aniqlash tasodifiy
(randomized) MAC manzillar ishlatilganda ishlamaydi — bu qurilmalarning
maxfiylik funksiyasi bo'lib, Android 10+ da ko'plab tarmoqlarga ulanishda
standart holatga aylangan.

## Loyiha tuzilmasi

```
app/src/main/java/com/wifiinfopro/app/
├── MainActivity.kt              # Navigation host, bottom bar
├── WifiInfoApp.kt                # Application class (osmdroid config)
├── data/
│   ├── WifiNetworkInfo.kt        # Asosiy data model
│   ├── WifiScanner.kt            # WifiManager skanerlash logikasi
│   ├── MacVendorLookup.kt        # OUI/vendor jadvali
│   └── SpeedTestManager.kt       # Internet tezligi testi
├── viewmodel/
│   └── WifiViewModel.kt          # UI state, filtr, saralash
└── ui/
    ├── theme/                    # Material3 rang, tipografiya
    ├── components/                # NetworkCard, grafiklar, PermissionGate
    └── screens/                  # Asosiy, tafsilot, xarita, kanal, tezlik, sozlamalar
```

## Google Play talablariga moslik bo'yicha eslatmalar

- `ACCESS_FINE_LOCATION` ruxsati ishlatilishi Play Console'da
  **"Location permission declaration"** formasida asoslanishi kerak
  (Wi-Fi skanerlash uchun Android talabi sifatida).
- Ilova hech qanday shaxsiy ma'lumotni serverga yubormaydi — barcha
  qayta ishlash qurilmada (on-device) amalga oshiriladi. Bu Play Store
  Data Safety bo'limida shunday deb ko'rsatilishi kerak.
- Tezlik testi funksiyasi tashqi serverga (masalan, Cloudflare speed
  endpoint) so'rov yuboradi — buni ham Data Safety formasida
  "internetga ulanish" sifatida ko'rsatish tavsiya etiladi.
- Ilova nashr etishdan oldin haqiqiy qurilmalarda (turli Android
  versiyalari: 8, 10, 12, 13, 14) sinovdan o'tkazilishi tavsiya etiladi,
  chunki Wi-Fi skanerlash API xatti-harakati versiyalar bo'yicha farq qiladi
  (masalan, Android 9+ da `startScan()` chastotasi cheklangan).

## Keyingi qadamlar (tavsiya)

- To'liq IEEE OUI bazasini (yoki onlayn API) qo'shish orqali vendor
  aniqlashni kengaytirish
- Push-based signal monitoring uchun Foreground Service qo'shish
- Xotira/tarixni Room bazasida saqlab, ilova qayta ishga tushirilganda
  ham grafiklarni saqlab qolish
