# WiFi Info Pro proguard rules
-keepattributes *Annotation*
-keep class com.wifiinfopro.app.data.** { *; }
-dontwarn org.osmdroid.**
