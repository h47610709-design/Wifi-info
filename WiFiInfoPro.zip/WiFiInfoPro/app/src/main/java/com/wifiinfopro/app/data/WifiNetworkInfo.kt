package com.wifiinfopro.app.data

/**
 * Xavfsizlik turi
 */
enum class SecurityType {
    OPEN, WEP, WPA, WPA2, WPA3, WPA2_WPA3, ENTERPRISE, UNKNOWN
}

/**
 * Chastota diapazoni
 */
enum class FrequencyBand {
    GHZ_2_4, GHZ_5, GHZ_6, UNKNOWN
}

/**
 * Wi-Fi standarti (802.11 generatsiyasi)
 */
enum class WifiStandard(val label: String) {
    LEGACY("802.11a/b/g"),
    N("802.11n (Wi-Fi 4)"),
    AC("802.11ac (Wi-Fi 5)"),
    AX("802.11ax (Wi-Fi 6/6E)"),
    BE("802.11be (Wi-Fi 7)"),
    UNKNOWN("Noma'lum")
}

/**
 * Bitta skanerlangan Wi-Fi tarmog'i haqida to'liq ma'lumot.
 * Faqat Android tizimi ruxsat bergan (ScanResult orqali olinadigan) ma'lumotlar saqlanadi.
 */
data class WifiNetworkInfo(
    val ssid: String,
    val bssid: String,
    val rssiDbm: Int,
    val frequencyMhz: Int,
    val channel: Int,
    val channelWidthMhz: Int,
    val securityType: SecurityType,
    val capabilities: String,
    val standard: WifiStandard,
    val vendor: String,
    val maxTheoreticalMbps: Int,
    val timestampMillis: Long,
    val is80211mcResponder: Boolean = false,
    val centerFreq0: Int = 0,
    val centerFreq1: Int = 0
) {
    /** Signal foizga aylantirish (odatiy: -100dBm=0%, -30dBm=100%) */
    val signalPercent: Int
        get() {
            val percent = ((rssiDbm + 100) * (100.0 / 70.0))
            return percent.coerceIn(0.0, 100.0).toInt()
        }

    val band: FrequencyBand
        get() = when {
            frequencyMhz in 2400..2500 -> FrequencyBand.GHZ_2_4
            frequencyMhz in 4900..5900 -> FrequencyBand.GHZ_5
            frequencyMhz in 5925..7125 -> FrequencyBand.GHZ_6
            else -> FrequencyBand.UNKNOWN
        }

    /** Signal sifati tavsifi */
    val qualityLabel: String
        get() = when {
            rssiDbm >= -50 -> "A'lo"
            rssiDbm >= -60 -> "Yaxshi"
            rssiDbm >= -70 -> "O'rtacha"
            rssiDbm >= -80 -> "Zaif"
            else -> "Juda zaif"
        }

    /** Erkin fazo yo'qotilishi formulasi asosida taxminiy masofa (metr) */
    val estimatedDistanceMeters: Double
        get() {
            // FSPL: d = 10 ^ ((TxPower - RSSI) / (10 * n))
            // TxPower odatda ~ -40dBm (1m masofada), n = muhit koeffitsienti (2.0-4.0)
            val txPowerAt1m = -40.0
            val pathLossExponent = 2.8
            val exponent = (txPowerAt1m - rssiDbm) / (10.0 * pathLossExponent)
            return Math.pow(10.0, exponent)
        }
}
