package com.wifiinfopro.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.R
import com.wifiinfopro.app.data.WifiNetworkInfo
import com.wifiinfopro.app.ui.components.SecurityBadge
import com.wifiinfopro.app.ui.components.SignalHistoryChart
import com.wifiinfopro.app.ui.theme.signalColor
import com.wifiinfopro.app.viewmodel.WifiViewModel
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkDetailScreen(
    viewModel: WifiViewModel,
    bssid: String,
    onBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()
    val network = uiState.networks.find { it.bssid == bssid }

    var history by remember { mutableStateOf(viewModel.historyFor(bssid)) }
    LaunchedEffect(bssid) {
        while (true) {
            history = viewModel.historyFor(bssid)
            delay(2000)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(stringResource(R.string.detail_title)) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = null)
                    }
                }
            )
        }
    ) { padding ->
        if (network == null) {
            Text(
                text = stringResource(R.string.no_networks_found),
                modifier = Modifier.padding(padding).padding(24.dp)
            )
            return@Scaffold
        }

        Column(
            modifier = Modifier
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            Text(text = network.ssid, style = MaterialTheme.typography.titleLarge)
            Row(modifier = Modifier.padding(top = 8.dp)) {
                SecurityBadge(network.securityType)
            }

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    DetailRow(stringResource(R.string.detail_bssid), network.bssid)
                    DetailRow(stringResource(R.string.detail_signal), "${network.rssiDbm} dBm (${network.signalPercent}%)")
                    DetailRow(stringResource(R.string.detail_quality), network.qualityLabel)
                    DetailRow(stringResource(R.string.detail_frequency), "${network.frequencyMhz} MHz")
                    DetailRow(stringResource(R.string.detail_channel), network.channel.toString())
                    DetailRow(stringResource(R.string.detail_channel_width), "${network.channelWidthMhz} MHz")
                    DetailRow(stringResource(R.string.detail_standard), network.standard.label)
                    DetailRow(stringResource(R.string.detail_vendor), network.vendor)
                    DetailRow(stringResource(R.string.detail_max_speed), "${network.maxTheoreticalMbps} Mbps")
                    DetailRow(
                        stringResource(R.string.detail_distance),
                        "~${"%.1f".format(network.estimatedDistanceMeters)} m"
                    )
                }
            }

            Text(
                text = stringResource(R.string.detail_history),
                style = MaterialTheme.typography.titleMedium,
                modifier = Modifier.padding(top = 24.dp, bottom = 8.dp)
            )
            SignalHistoryChart(
                history = history,
                color = signalColor(network.rssiDbm),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(180.dp)
            )

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 24.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f)
                )
            ) {
                Text(
                    text = stringResource(R.string.unavailable_notice),
                    modifier = Modifier.padding(12.dp),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Text(text = value, style = MaterialTheme.typography.bodyMedium)
    }
}
