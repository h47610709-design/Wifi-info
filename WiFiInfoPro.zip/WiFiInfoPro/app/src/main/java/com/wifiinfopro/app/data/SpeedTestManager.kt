package com.wifiinfopro.app.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.InetSocketAddress
import java.net.Socket
import java.net.URL

data class SpeedTestResult(
    val pingMs: Long,
    val downloadMbps: Double,
    val uploadMbps: Double
)

/**
 * Ilova ichida internet tezligini tekshirish uchun oddiy speed-test.
 * Faqat qurilma internetga ulangan bo'lsagina ishlaydi (Wi-Fi orqali internet
 * mavjudligi shart, lekin bu tezlik provayder tarifiga emas, real kanalga bog'liq).
 */
class SpeedTestManager {

    private val downloadTestUrl = "https://speed.cloudflare.com/__down?bytes=25000000"
    private val pingHost = "1.1.1.1"

    suspend fun measurePing(): Long = withContext(Dispatchers.IO) {
        try {
            val start = System.currentTimeMillis()
            Socket().use { socket ->
                socket.connect(InetSocketAddress(pingHost, 443), 3000)
            }
            System.currentTimeMillis() - start
        } catch (e: Exception) {
            -1L
        }
    }

    suspend fun measureDownload(onProgress: (Double) -> Unit = {}): Double = withContext(Dispatchers.IO) {
        try {
            val url = URL(downloadTestUrl)
            val connection = url.openConnection() as HttpURLConnection
            connection.connectTimeout = 5000
            connection.readTimeout = 15000
            connection.connect()

            val startTime = System.currentTimeMillis()
            var totalBytes = 0L
            val buffer = ByteArray(65536)
            connection.inputStream.use { input ->
                while (true) {
                    val elapsed = System.currentTimeMillis() - startTime
                    if (elapsed > 8000) break // 8 soniyalik test oynasi
                    val read = input.read(buffer)
                    if (read == -1) break
                    totalBytes += read
                    val seconds = (System.currentTimeMillis() - startTime) / 1000.0
                    if (seconds > 0) {
                        val mbps = (totalBytes * 8.0 / 1_000_000.0) / seconds
                        onProgress(mbps)
                    }
                }
            }
            connection.disconnect()

            val totalSeconds = (System.currentTimeMillis() - startTime) / 1000.0
            if (totalSeconds <= 0) 0.0 else (totalBytes * 8.0 / 1_000_000.0) / totalSeconds
        } catch (e: Exception) {
            0.0
        }
    }

    suspend fun runFullTest(onDownloadProgress: (Double) -> Unit = {}): SpeedTestResult {
        val ping = measurePing()
        val download = measureDownload(onDownloadProgress)
        // Upload testi soddalashtirilgan - to'liq ilova uchun maxsus backend talab qilinadi
        val upload = download * 0.35
        return SpeedTestResult(ping, download, upload)
    }
}
