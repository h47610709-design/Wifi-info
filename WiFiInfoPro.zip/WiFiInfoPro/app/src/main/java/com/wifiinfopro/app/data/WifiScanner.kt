package com.wifiinfopro.app.data

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.wifi.ScanResult
import android.net.wifi.WifiManager
import android.os.Build
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.callbackFlow

/**
 * Wi-Fi tarmoqlarini Android WifiManager API orqali skanerlaydigan asosiy klass.
 *
 * MUHIM: Android xavfsizlik siyosati sababli, bu klass faqat tizim ScanResult
 * obyekti orqali taqdim etadigan ma'lumotlarni o'qiy oladi. Internet tarifi,
 * abonent nomi yoki provayder balansi kabi ma'lumotlar TIZIM DARAJASIDA
 * mavjud emas va hech qanday ilova ularni ololmaydi.
 */
class WifiScanner(private val context: Context) {

    private val wifiManager: WifiManager =
        context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager

    private val _scanResults = MutableStateFlow<List<WifiNetworkInfo>>(emptyList())
    val scanResults: StateFlow<List<WifiNetworkInfo>> = _scanResults

    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning

    /** Har bir SSID/BSSID uchun oxirgi 60 ta signal o'qishini saqlaydi (grafik uchun) */
    private val signalHistory = mutableMapOf<String, MutableList<Pair<Long, Int>>>()

    fun getHistoryFor(bssid: String): List<Pair<Long, Int>> =
        signalHistory[bssid]?.toList() ?: emptyList()

    /**
     * Bitta marta skanerlashni ishga tushiradi.
     * WifiManager.startScan() Android 9+ da tez-tez chaqirilganda rate-limit qilinadi,
     * shu sabab natijalar keshdan (getScanResults) ham o'qiladi.
     */
    fun requestScan(): Boolean {
        _isScanning.value = true
        return wifiManager.startScan()
    }

    /**
     * Doimiy (real-vaqt) skanerlash oqimini ochadi. Har safar tizim yangi
     * SCAN_RESULTS_AVAILABLE_ACTION broadcast yuborganda ro'yxat yangilanadi.
     */
    fun observeScans(intervalMillis: Long = 4000L): Flow<List<WifiNetworkInfo>> = callbackFlow {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(ctx: Context?, intent: Intent?) {
                val success = intent?.getBooleanExtra(WifiManager.EXTRA_RESULTS_UPDATED, false) ?: false
                val results = processResults(wifiManager.scanResults)
                _scanResults.value = results
                _isScanning.value = false
                trySend(results)
            }
        }
        val filter = IntentFilter(WifiManager.SCAN_RESULTS_AVAILABLE_ACTION)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            context.registerReceiver(receiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            context.registerReceiver(receiver, filter)
        }

        // Birinchi skanerlashni darhol boshlash
        requestScan()

        awaitClose { context.unregisterReceiver(receiver) }
    }

    private fun processResults(raw: List<ScanResult>): List<WifiNetworkInfo> {
        val now = System.currentTimeMillis()
        return raw.map { result ->
            val info = mapScanResult(result, now)
            // Tarixga qo'shish
            val list = signalHistory.getOrPut(info.bssid) { mutableListOf() }
            list.add(now to info.rssiDbm)
            if (list.size > 60) list.removeAt(0)
            info
        }.sortedByDescending { it.rssiDbm }
    }

    private fun mapScanResult(result: ScanResult, timestamp: Long): WifiNetworkInfo {
        val ssid = if (result.SSID.isNullOrBlank()) "(Yashirin tarmoq)" else result.SSID
        val bssid = result.BSSID ?: "00:00:00:00:00:00"
        val capabilities = result.capabilities ?: ""
        val security = parseSecurityType(capabilities)
        val channel = frequencyToChannel(result.frequency)
        val channelWidth = parseChannelWidth(result)
        val standard = parseStandard(result, capabilities)
        val vendor = MacVendorLookup.lookup(bssid)
        val maxSpeed = estimateMaxSpeedMbps(standard, channelWidth, result.frequency)

        return WifiNetworkInfo(
            ssid = ssid,
            bssid = bssid,
            rssiDbm = result.level,
            frequencyMhz = result.frequency,
            channel = channel,
            channelWidthMhz = channelWidth,
            securityType = security,
            capabilities = capabilities,
            standard = standard,
            vendor = vendor,
            maxTheoreticalMbps = maxSpeed,
            timestampMillis = timestamp,
            centerFreq0 = try { result.centerFreq0 } catch (e: Exception) { 0 },
            centerFreq1 = try { result.centerFreq1 } catch (e: Exception) { 0 }
        )
    }

    private fun parseSecurityType(capabilities: String): SecurityType {
        val caps = capabilities.uppercase()
        return when {
            caps.contains("WPA3") && caps.contains("WPA2") -> SecurityType.WPA2_WPA3
            caps.contains("WPA3") -> SecurityType.WPA3
            caps.contains("EAP") -> SecurityType.ENTERPRISE
            caps.contains("WPA2") -> SecurityType.WPA2
            caps.contains("WPA") -> SecurityType.WPA
            caps.contains("WEP") -> SecurityType.WEP
            caps.isBlank() || caps == "[ESS]" -> SecurityType.OPEN
            else -> SecurityType.UNKNOWN
        }
    }

    private fun frequencyToChannel(freqMhz: Int): Int {
        return when (freqMhz) {
            in 2412..2484 -> if (freqMhz == 2484) 14 else (freqMhz - 2412) / 5 + 1
            in 5170..5825 -> (freqMhz - 5000) / 5
            in 5925..7125 -> (freqMhz - 5950) / 5 + 1
            else -> -1
        }
    }

    private fun parseChannelWidth(result: ScanResult): Int {
        return try {
            when (result.channelWidth) {
                ScanResult.CHANNEL_WIDTH_20MHZ -> 20
                ScanResult.CHANNEL_WIDTH_40MHZ -> 40
                ScanResult.CHANNEL_WIDTH_80MHZ -> 80
                ScanResult.CHANNEL_WIDTH_160MHZ -> 160
                ScanResult.CHANNEL_WIDTH_80MHZ_PLUS_MHZ -> 80
                else -> 20
            }
        } catch (e: Exception) {
            20
        }
    }

    private fun parseStandard(result: ScanResult, capabilities: String): WifiStandard {
        // Android 11+ (R) da wifiStandard maydoni mavjud
        return try {
            val std = result.javaClass.getMethod("getWifiStandard").invoke(result) as? Int
            when (std) {
                6 -> WifiStandard.AX  // ScanResult.WIFI_STANDARD_11AX
                4 -> WifiStandard.AC  // WIFI_STANDARD_11AC
                5 -> WifiStandard.N   // WIFI_STANDARD_11N (legacy const varies)
                8 -> WifiStandard.BE  // WIFI_STANDARD_11BE (yangi qurilmalarda)
                else -> guessStandardFromFrequency(result.frequency, capabilities)
            }
        } catch (e: Exception) {
            guessStandardFromFrequency(result.frequency, capabilities)
        }
    }

    private fun guessStandardFromFrequency(freq: Int, capabilities: String): WifiStandard {
        return when {
            freq in 5925..7125 -> WifiStandard.AX // 6GHz faqat Wi-Fi 6E/7 da mavjud
            capabilities.contains("VHT") -> WifiStandard.AC
            capabilities.contains("HT") -> WifiStandard.N
            else -> WifiStandard.LEGACY
        }
    }

    private fun estimateMaxSpeedMbps(standard: WifiStandard, widthMhz: Int, freq: Int): Int {
        // Taxminiy nazariy maksimal tezlik (soddalashtirilgan, 1 fazoviy oqim uchun bazaviy qiymatlar)
        val base = when (standard) {
            WifiStandard.LEGACY -> 54
            WifiStandard.N -> if (widthMhz >= 40) 300 else 150
            WifiStandard.AC -> when {
                widthMhz >= 160 -> 866
                widthMhz >= 80 -> 433
                else -> 200
            }
            WifiStandard.AX -> when {
                widthMhz >= 160 -> 1201
                widthMhz >= 80 -> 600
                else -> 300
            }
            WifiStandard.BE -> when {
                widthMhz >= 320 -> 2882
                widthMhz >= 160 -> 1441
                else -> 700
            }
            WifiStandard.UNKNOWN -> 54
        }
        return base
    }
}
