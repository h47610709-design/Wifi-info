package com.wifiinfopro.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.R
import com.wifiinfopro.app.viewmodel.WifiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SpeedTestScreen(viewModel: WifiViewModel) {
    val result by viewModel.speedTestResult.collectAsState()
    val running by viewModel.speedTestRunning.collectAsState()
    val liveDownload by viewModel.liveDownloadMbps.collectAsState()

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.speedtest_title)) }) }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            if (running) {
                CircularProgressIndicator(modifier = Modifier.size(72.dp))
                Text(
                    text = stringResource(R.string.speedtest_running),
                    modifier = Modifier.padding(top = 16.dp)
                )
                Text(
                    text = "${"%.1f".format(liveDownload)} Mbps",
                    style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.padding(top = 8.dp)
                )
            } else {
                Icon(
                    imageVector = Icons.Filled.Speed,
                    contentDescription = null,
                    modifier = Modifier.size(64.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
                Button(
                    onClick = { viewModel.runSpeedTest() },
                    modifier = Modifier.padding(top = 24.dp)
                ) {
                    Text(stringResource(R.string.speedtest_start))
                }

                result?.let { r ->
                    Column(modifier = Modifier.padding(top = 32.dp)) {
                        ResultRow(stringResource(R.string.speedtest_ping), "${r.pingMs} ms")
                        ResultRow(stringResource(R.string.speedtest_download), "${"%.1f".format(r.downloadMbps)} Mbps")
                        ResultRow(stringResource(R.string.speedtest_upload), "${"%.1f".format(r.uploadMbps)} Mbps")
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(label: String, value: String) {
    androidx.compose.foundation.layout.Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
        Text(text = value, style = MaterialTheme.typography.titleMedium)
    }
}
