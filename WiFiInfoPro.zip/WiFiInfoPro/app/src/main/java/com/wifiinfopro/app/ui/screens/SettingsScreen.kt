package com.wifiinfopro.app.ui.screens

import android.content.Intent
import android.os.Build
import android.os.LocaleList
import android.provider.Settings
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ListItem
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.R

enum class ThemeOption { LIGHT, DARK, SYSTEM }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(onThemeChange: (Boolean?) -> Unit) {
    val context = LocalContext.current
    var selectedTheme by remember { mutableStateOf(ThemeOption.SYSTEM) }

    Scaffold(
        topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_settings)) }) }
    ) { padding ->
        Column(modifier = Modifier.padding(padding).fillMaxWidth()) {
            Text(
                text = stringResource(R.string.settings_theme),
                modifier = Modifier.padding(16.dp),
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
            )

            ThemeRadioItem(
                label = stringResource(R.string.settings_theme_light),
                selected = selectedTheme == ThemeOption.LIGHT
            ) {
                selectedTheme = ThemeOption.LIGHT
                onThemeChange(false)
            }
            ThemeRadioItem(
                label = stringResource(R.string.settings_theme_dark),
                selected = selectedTheme == ThemeOption.DARK
            ) {
                selectedTheme = ThemeOption.DARK
                onThemeChange(true)
            }
            ThemeRadioItem(
                label = stringResource(R.string.settings_theme_system),
                selected = selectedTheme == ThemeOption.SYSTEM
            ) {
                selectedTheme = ThemeOption.SYSTEM
                onThemeChange(null)
            }

            Divider(modifier = Modifier.padding(vertical = 8.dp))

            Text(
                text = stringResource(R.string.settings_language),
                modifier = Modifier.padding(16.dp),
                style = androidx.compose.material3.MaterialTheme.typography.titleMedium
            )
            ListItem(
                headlineContent = { Text("O'zbekcha / Русский / English") },
                supportingContent = { Text("Tizim tili sozlamalaridan boshqariladi") },
                modifier = Modifier.clickableOpenLocaleSettings(context)
            )
        }
    }
}

@Composable
private fun ThemeRadioItem(label: String, selected: Boolean, onClick: () -> Unit) {
    ListItem(
        headlineContent = { Text(label) },
        leadingContent = { RadioButton(selected = selected, onClick = onClick) },
        modifier = Modifier.clickableSimple(onClick)
    )
}

private fun Modifier.clickableSimple(onClick: () -> Unit): Modifier =
    this.then(androidx.compose.foundation.clickable(onClick = onClick))

private fun Modifier.clickableOpenLocaleSettings(context: android.content.Context): Modifier =
    this.then(androidx.compose.foundation.clickable {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val intent = Intent(Settings.ACTION_APP_LOCALE_SETTINGS)
            intent.data = android.net.Uri.parse("package:" + context.packageName)
            context.startActivity(intent)
        }
    })
