package com.wifiinfopro.app

import android.app.Application
import org.osmdroid.config.Configuration

class WifiInfoApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // osmdroid xarita kutubxonasi uchun konfiguratsiya (user-agent talab qiladi)
        Configuration.getInstance().userAgentValue = packageName
        Configuration.getInstance().load(
            this,
            getSharedPreferences("osmdroid_prefs", MODE_PRIVATE)
        )
    }
}
