package com.wifiinfopro.app.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.wifiinfopro.app.R
import com.wifiinfopro.app.ui.components.PermissionGate
import com.wifiinfopro.app.ui.theme.signalColor
import com.wifiinfopro.app.viewmodel.WifiViewModel
import org.osmdroid.config.Configuration
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.mylocation.GpsMyLocationProvider
import org.osmdroid.views.overlay.mylocation.MyLocationNewOverlay

/**
 * MUHIM: Wi-Fi skanerlash natijalari GPS koordinatasini o'z ichiga olmaydi.
 * Android ScanResult hech qanday joylashuv ma'lumotini bermaydi. Shu sabab bu
 * ekranda faqat foydalanuvchining JORIY joylashuvi va shu nuqtada aniqlangan
 * tarmoqlar ro'yxati (masofa taxminiga asoslangan doiralar bilan) ko'rsatiladi -
 * har bir routerning aniq GPS nuqtasini triangulyatsiyasiz aniqlash mumkin emas.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(viewModel: WifiViewModel) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()

    PermissionGate {
        Scaffold(
            topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_map)) }) }
        ) { padding ->
            AndroidView(
                modifier = Modifier
                    .fillMaxSize(),
                factory = { ctx ->
                    Configuration.getInstance().load(ctx, ctx.getSharedPreferences("osmdroid_prefs", 0))
                    MapView(ctx).apply {
                        setTileSource(TileSourceFactory.MAPNIK)
                        setMultiTouchControls(true)
                        controller.setZoom(17.0)

                        val hasFineLocation = ContextCompat.checkSelfPermission(
                            ctx, Manifest.permission.ACCESS_FINE_LOCATION
                        ) == PackageManager.PERMISSION_GRANTED

                        if (hasFineLocation) {
                            val locationOverlay = MyLocationNewOverlay(GpsMyLocationProvider(ctx), this)
                            locationOverlay.enableMyLocation()
                            locationOverlay.runOnFirstFix {
                                post {
                                    controller.animateTo(locationOverlay.myLocation)
                                }
                            }
                            overlays.add(locationOverlay)
                        }
                    }
                },
                update = { mapView ->
                    // Eng kuchli tarmoqlarni markerlar sifatida ko'rsatish (foydalanuvchi nuqtasi atrofida)
                    val myLocation = (mapView.overlays.find { it is MyLocationNewOverlay } as? MyLocationNewOverlay)
                        ?.myLocation ?: return@AndroidView

                    mapView.overlays.removeAll { it is Marker }
                    uiState.networks.take(15).forEachIndexed { index, network ->
                        // Taxminiy joylashuvni signal masofasi asosida tasodifiy burchakda joylashtirish
                        val angle = (index * 137.5) % 360
                        val distanceDeg = (network.estimatedDistanceMeters / 111_000.0)
                        val lat = myLocation.latitude + distanceDeg * Math.cos(Math.toRadians(angle))
                        val lon = myLocation.longitude + distanceDeg * Math.sin(Math.toRadians(angle))

                        val marker = Marker(mapView)
                        marker.position = GeoPoint(lat, lon)
                        marker.title = network.ssid
                        marker.snippet = "${network.rssiDbm} dBm • ~${"%.0f".format(network.estimatedDistanceMeters)}m"
                        mapView.overlays.add(marker)
                    }
                    mapView.invalidate()
                }
            )
        }
    }
}
