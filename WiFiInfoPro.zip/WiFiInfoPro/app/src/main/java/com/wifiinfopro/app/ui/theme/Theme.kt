package com.wifiinfopro.app.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val LightColors = lightColorScheme(
    primary = PrimaryBlue,
    secondary = AccentViolet,
    tertiary = AccentCyan,
    background = LightBackground,
    surface = LightSurface,
    onBackground = LightOnSurface,
    onSurface = LightOnSurface
)

private val DarkColors = darkColorScheme(
    primary = PrimaryBlue,
    secondary = AccentViolet,
    tertiary = AccentCyan,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = DarkOnSurface,
    onSurface = DarkOnSurface
)

@Composable
fun WifiInfoProTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // brend ranglarni saqlash uchun default o'chirilgan
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColors
        else -> LightColors
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = AppTypography,
        content = content
    )
}

/** Signal kuchiga qarab rang qaytaradi (RSSI dBm asosida) */
fun signalColor(rssiDbm: Int): Color = when {
    rssiDbm >= -50 -> SignalExcellent
    rssiDbm >= -60 -> SignalGood
    rssiDbm >= -70 -> SignalMedium
    rssiDbm >= -80 -> SignalWeak
    else -> SignalVeryWeak
}
