package com.wifiinfopro.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wifiinfopro.app.data.SpeedTestManager
import com.wifiinfopro.app.data.SpeedTestResult
import com.wifiinfopro.app.data.WifiNetworkInfo
import com.wifiinfopro.app.data.WifiScanner
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class SortMode { SIGNAL_STRONGEST, SIGNAL_WEAKEST, NAME_AZ, CHANNEL }

data class WifiUiState(
    val networks: List<WifiNetworkInfo> = emptyList(),
    val isScanning: Boolean = false,
    val searchQuery: String = "",
    val sortMode: SortMode = SortMode.SIGNAL_STRONGEST,
    val filterBand2_4: Boolean = true,
    val filterBand5: Boolean = true,
    val filterBand6: Boolean = true,
    val onlyOpenNetworks: Boolean = false
)

class WifiViewModel(app: Application) : AndroidViewModel(app) {

    private val scanner = WifiScanner(app)
    val speedTestManager = SpeedTestManager()

    private val _searchQuery = MutableStateFlow("")
    private val _sortMode = MutableStateFlow(SortMode.SIGNAL_STRONGEST)
    private val _filters = MutableStateFlow(Triple(true, true, true))
    private val _onlyOpen = MutableStateFlow(false)

    private val _speedTestResult = MutableStateFlow<SpeedTestResult?>(null)
    val speedTestResult: StateFlow<SpeedTestResult?> = _speedTestResult

    private val _speedTestRunning = MutableStateFlow(false)
    val speedTestRunning: StateFlow<Boolean> = _speedTestRunning

    private val _liveDownloadMbps = MutableStateFlow(0.0)
    val liveDownloadMbps: StateFlow<Double> = _liveDownloadMbps

    val uiState: StateFlow<WifiUiState> = combine(
        scanner.scanResults,
        scanner.isScanning,
        _searchQuery,
        _sortMode,
        _filters,
        _onlyOpen
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val networks = values[0] as List<WifiNetworkInfo>
        val scanning = values[1] as Boolean
        val query = values[2] as String
        val sort = values[3] as SortMode
        val (f24, f5, f6) = values[4] as Triple<Boolean, Boolean, Boolean>
        val onlyOpen = values[5] as Boolean

        var filtered = networks.filter { net ->
            val bandOk = when (net.band.name) {
                "GHZ_2_4" -> f24
                "GHZ_5" -> f5
                "GHZ_6" -> f6
                else -> true
            }
            val queryOk = query.isBlank() ||
                net.ssid.contains(query, ignoreCase = true) ||
                net.bssid.contains(query, ignoreCase = true) ||
                net.vendor.contains(query, ignoreCase = true)
            val openOk = !onlyOpen || net.securityType.name == "OPEN"
            bandOk && queryOk && openOk
        }

        filtered = when (sort) {
            SortMode.SIGNAL_STRONGEST -> filtered.sortedByDescending { it.rssiDbm }
            SortMode.SIGNAL_WEAKEST -> filtered.sortedBy { it.rssiDbm }
            SortMode.NAME_AZ -> filtered.sortedBy { it.ssid.lowercase() }
            SortMode.CHANNEL -> filtered.sortedBy { it.channel }
        }

        WifiUiState(
            networks = filtered,
            isScanning = scanning,
            searchQuery = query,
            sortMode = sort,
            filterBand2_4 = f24,
            filterBand5 = f5,
            filterBand6 = f6,
            onlyOpenNetworks = onlyOpen
        )
    }.stateIn(
        viewModelScope,
        kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000),
        WifiUiState()
    )

    init {
        viewModelScope.launch {
            scanner.observeScans().collect { }
        }
    }

    fun rescan() = scanner.requestScan()

    fun setSearchQuery(q: String) { _searchQuery.value = q }
    fun setSortMode(mode: SortMode) { _sortMode.value = mode }
    fun toggleBand2_4() { _filters.update { it.copy(first = !it.first) } }
    fun toggleBand5() { _filters.update { it.copy(second = !it.second) } }
    fun toggleBand6() { _filters.update { it.copy(third = !it.third) } }
    fun toggleOnlyOpen() { _onlyOpen.value = !_onlyOpen.value }

    fun historyFor(bssid: String) = scanner.getHistoryFor(bssid)

    fun runSpeedTest() {
        viewModelScope.launch {
            _speedTestRunning.value = true
            _liveDownloadMbps.value = 0.0
            val result = speedTestManager.runFullTest { progress ->
                _liveDownloadMbps.value = progress
            }
            _speedTestResult.value = result
            _speedTestRunning.value = false
        }
    }

    private fun MutableStateFlow<Triple<Boolean, Boolean, Boolean>>.update(
        transform: (Triple<Boolean, Boolean, Boolean>) -> Triple<Boolean, Boolean, Boolean>
    ) {
        value = transform(value)
    }

    private fun Triple<Boolean, Boolean, Boolean>.copy(
        first: Boolean = this.first,
        second: Boolean = this.second,
        third: Boolean = this.third
    ) = Triple(first, second, third)
}
