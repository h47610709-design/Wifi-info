package com.wifiinfopro.app

import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.wifiinfopro.app.ui.screens.ChannelGraphScreen
import com.wifiinfopro.app.ui.screens.MainScreen
import com.wifiinfopro.app.ui.screens.MapScreen
import com.wifiinfopro.app.ui.screens.NetworkDetailScreen
import com.wifiinfopro.app.ui.screens.SettingsScreen
import com.wifiinfopro.app.ui.screens.SpeedTestScreen
import com.wifiinfopro.app.ui.theme.WifiInfoProTheme
import com.wifiinfopro.app.viewmodel.WifiViewModel

sealed class Screen(val route: String, val labelRes: Int) {
    data object Networks : Screen("networks", R.string.tab_networks)
    data object Map : Screen("map", R.string.tab_map)
    data object Channels : Screen("channels", R.string.tab_channels)
    data object SpeedTest : Screen("speedtest", R.string.tab_speedtest)
    data object Settings : Screen("settings", R.string.tab_settings)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            var darkModeOverride by androidx.compose.runtime.remember {
                androidx.compose.runtime.mutableStateOf<Boolean?>(null)
            }
            WifiInfoProTheme(
                darkTheme = darkModeOverride ?: androidx.compose.foundation.isSystemInDarkTheme()
            ) {
                AppRoot(
                    onThemeChange = { darkModeOverride = it }
                )
            }
        }
    }
}

@Composable
fun AppRoot(onThemeChange: (Boolean?) -> Unit) {
    val navController = rememberNavController()
    val viewModel: WifiViewModel = viewModel()

    val items = listOf(Screen.Networks, Screen.Map, Screen.Channels, Screen.SpeedTest, Screen.Settings)

    Scaffold(
        bottomBar = {
            NavigationBar {
                val navBackStackEntry by navController.currentBackStackEntryAsState()
                val currentDestination = navBackStackEntry?.destination

                items.forEach { screen ->
                    val selected = currentDestination?.hierarchy?.any { it.route == screen.route } == true
                    NavigationBarItem(
                        selected = selected,
                        onClick = {
                            navController.navigate(screen.route) {
                                popUpTo(navController.graph.findStartDestination().id) {
                                    saveState = true
                                }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = when (screen) {
                                    Screen.Networks -> Icons.Filled.List
                                    Screen.Map -> Icons.Filled.LocationOn
                                    Screen.Channels -> Icons.Filled.SignalCellularAlt
                                    Screen.SpeedTest -> Icons.Filled.Speed
                                    Screen.Settings -> Icons.Filled.Settings
                                },
                                contentDescription = null
                            )
                        },
                        label = { Text(stringResourceCompat(screen.labelRes)) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = Screen.Networks.route,
            modifier = Modifier.padding(padding)
        ) {
            composable(Screen.Networks.route) {
                MainScreen(
                    viewModel = viewModel,
                    onNetworkClick = { bssid ->
                        navController.navigate("detail/$bssid")
                    }
                )
            }
            composable("detail/{bssid}") { backStackEntry ->
                val bssid = backStackEntry.arguments?.getString("bssid") ?: ""
                NetworkDetailScreen(viewModel = viewModel, bssid = bssid, onBack = { navController.popBackStack() })
            }
            composable(Screen.Map.route) {
                MapScreen(viewModel = viewModel)
            }
            composable(Screen.Channels.route) {
                ChannelGraphScreen(viewModel = viewModel)
            }
            composable(Screen.SpeedTest.route) {
                SpeedTestScreen(viewModel = viewModel)
            }
            composable(Screen.Settings.route) {
                SettingsScreen(onThemeChange = onThemeChange)
            }
        }
    }
}

@Composable
private fun stringResourceCompat(resId: Int): String =
    androidx.compose.ui.res.stringResource(id = resId)
