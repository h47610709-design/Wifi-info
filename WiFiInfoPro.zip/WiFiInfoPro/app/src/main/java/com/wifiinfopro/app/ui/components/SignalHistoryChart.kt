package com.wifiinfopro.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Paint
import androidx.compose.ui.graphics.PaintingStyle
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp

/**
 * Vaqt bo'yicha RSSI (dBm) o'zgarishini chizuvchi yengil, kutubxonasiz grafik.
 */
@Composable
fun SignalHistoryChart(
    history: List<Pair<Long, Int>>,
    color: Color,
    modifier: Modifier = Modifier
) {
    if (history.size < 2) {
        androidx.compose.foundation.layout.Box(modifier = modifier, contentAlignment = Alignment.Center) {
            Text(
                text = "Ma'lumot to'planmoqda…",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
            )
        }
        return
    }

    val minRssi = -100
    val maxRssi = -30

    Canvas(modifier = modifier) {
        val widthStep = size.width / (history.size - 1).coerceAtLeast(1)
        val path = Path()
        val fillPath = Path()

        history.forEachIndexed { index, (_, rssi) ->
            val x = index * widthStep
            val normalized = ((rssi - minRssi).toFloat() / (maxRssi - minRssi)).coerceIn(0f, 1f)
            val y = size.height * (1f - normalized)
            if (index == 0) {
                path.moveTo(x, y)
                fillPath.moveTo(x, size.height)
                fillPath.lineTo(x, y)
            } else {
                path.lineTo(x, y)
                fillPath.lineTo(x, y)
            }
        }
        fillPath.lineTo(size.width, size.height)
        fillPath.close()

        drawPath(fillPath, color = color.copy(alpha = 0.15f))
        drawPath(path, color = color, style = Stroke(width = 4f))

        // Gorizontal grid chiziqlari
        val gridColor = Color.Gray.copy(alpha = 0.15f)
        for (i in 0..4) {
            val y = size.height * i / 4
            drawLine(gridColor, androidx.compose.ui.geometry.Offset(0f, y), androidx.compose.ui.geometry.Offset(size.width, y))
        }
    }
}
