package com.wifiinfopro.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.data.WifiNetworkInfo
import com.wifiinfopro.app.ui.theme.signalColor

/**
 * Har bir kanal bo'yicha nechta tarmoq bandligini va ularning signal
 * kuchini ko'rsatuvchi ustunli diagramma (Wi-Fi analyzer uslubida).
 */
@Composable
fun ChannelOccupancyChart(
    networks: List<WifiNetworkInfo>,
    channels: List<Int>,
    modifier: Modifier = Modifier
) {
    val grouped = networks.groupBy { it.channel }
    val maxCount = (grouped.values.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)

    Column(modifier = modifier) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp).then(Modifier)) {
                val channelList = channels
                val barWidth = size.width / channelList.size
                channelList.forEachIndexed { index, ch ->
                    val nets = grouped[ch].orEmpty()
                    val count = nets.size
                    val strongest = nets.maxByOrNull { it.rssiDbm }
                    val barHeightRatio = count.toFloat() / maxCount
                    val barHeight = size.height * barHeightRatio
                    val color = strongest?.let { signalColor(it.rssiDbm) } ?: Color.Gray.copy(alpha = 0.2f)

                    drawRect(
                        color = color.copy(alpha = if (count > 0) 0.8f else 0.15f),
                        topLeft = Offset(index * barWidth + barWidth * 0.15f, size.height - barHeight),
                        size = androidx.compose.ui.geometry.Size(barWidth * 0.7f, barHeight)
                    )
                }
            }
        }
        ChannelLabelsRow(channels)
    }
}

@Composable
private fun ChannelLabelsRow(channels: List<Int>) {
    androidx.compose.foundation.layout.Row(modifier = Modifier.fillMaxWidth()) {
        channels.forEach { ch ->
            Text(
                text = ch.toString(),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.weight(1f),
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
        }
    }
}
