package com.wifiinfopro.app.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FilterAlt
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Sort
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.R
import com.wifiinfopro.app.data.WifiNetworkInfo
import com.wifiinfopro.app.ui.components.PermissionGate
import com.wifiinfopro.app.viewmodel.SortMode
import com.wifiinfopro.app.viewmodel.WifiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    viewModel: WifiViewModel,
    onNetworkClick: (String) -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    PermissionGate {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text(stringResource(R.string.app_name)) })
            },
            floatingActionButton = {
                FloatingActionButton(onClick = { viewModel.rescan() }) {
                    Icon(Icons.Filled.Refresh, contentDescription = stringResource(R.string.rescan))
                }
            }
        ) { padding ->
            Column(modifier = Modifier.padding(padding)) {

                if (uiState.isScanning) {
                    LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                }

                SearchAndFilterBar(viewModel = viewModel, uiState = uiState)

                Text(
                    text = stringResource(R.string.found_networks, uiState.networks.size),
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                )

                if (uiState.networks.isEmpty() && !uiState.isScanning) {
                    Text(
                        text = stringResource(R.string.no_networks_found),
                        modifier = Modifier.padding(32.dp)
                    )
                } else {
                    val strongestBssid = uiState.networks.maxByOrNull { it.rssiDbm }?.bssid
                    LazyColumn(
                        contentPadding = PaddingValues(bottom = 96.dp)
                    ) {
                        items(uiState.networks, key = { it.bssid }) { network ->
                            com.wifiinfopro.app.ui.components.NetworkCard(
                                network = network,
                                isStrongest = network.bssid == strongestBssid,
                                onClick = { onNetworkClick(network.bssid) }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SearchAndFilterBar(
    viewModel: WifiViewModel,
    uiState: com.wifiinfopro.app.viewmodel.WifiUiState
) {
    var sortMenuExpanded by remember { mutableStateOf(false) }
    var filterMenuExpanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) {
        OutlinedTextField(
            value = uiState.searchQuery,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text(stringResource(R.string.search_hint)) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = null) },
            singleLine = true
        )

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(
                selected = uiState.filterBand2_4,
                onClick = { viewModel.toggleBand2_4() },
                label = { Text("2.4 GHz") }
            )
            FilterChip(
                selected = uiState.filterBand5,
                onClick = { viewModel.toggleBand5() },
                label = { Text("5 GHz") }
            )
            FilterChip(
                selected = uiState.filterBand6,
                onClick = { viewModel.toggleBand6() },
                label = { Text("6 GHz") }
            )
            FilterChip(
                selected = uiState.onlyOpenNetworks,
                onClick = { viewModel.toggleOnlyOpen() },
                label = { Text(stringResource(R.string.filter_open_only)) }
            )

            IconButton(onClick = { sortMenuExpanded = true }) {
                Icon(Icons.Filled.Sort, contentDescription = null)
            }
            DropdownMenu(expanded = sortMenuExpanded, onDismissRequest = { sortMenuExpanded = false }) {
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.sort_signal_strongest)) },
                    onClick = { viewModel.setSortMode(SortMode.SIGNAL_STRONGEST); sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.sort_signal_weakest)) },
                    onClick = { viewModel.setSortMode(SortMode.SIGNAL_WEAKEST); sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.sort_name)) },
                    onClick = { viewModel.setSortMode(SortMode.NAME_AZ); sortMenuExpanded = false }
                )
                DropdownMenuItem(
                    text = { Text(stringResource(R.string.sort_channel)) },
                    onClick = { viewModel.setSortMode(SortMode.CHANNEL); sortMenuExpanded = false }
                )
            }
        }
    }
}
