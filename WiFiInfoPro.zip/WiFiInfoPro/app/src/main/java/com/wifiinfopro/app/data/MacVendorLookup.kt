package com.wifiinfopro.app.data

/**
 * MAC manzilning birinchi 3 baytiga (OUI - Organizationally Unique Identifier)
 * asoslangan router/qurilma ishlab chiqaruvchisini aniqlash.
 *
 * Eslatma: Bu offline, lokal jadval. To'liq IEEE OUI bazasi ~50,000 dan ortiq
 * yozuvdan iborat bo'lib, ilova hajmini oshiradi. Shu sabab eng ko'p tarqalgan
 * router/tarmoq uskunalari ishlab chiqaruvchilari kiritilgan. Aniqlanmagan
 * hollarda "Noma'lum ishlab chiqaruvchi" qaytariladi.
 *
 * Ko'pgina zamonaviy qurilmalar tasodifiy (randomized/locally administered)
 * MAC manzillardan foydalanadi - bunday holatda ishlab chiqaruvchini aniqlash
 * texnik jihatdan mumkin emas (bu Wi-Fi standartining maxfiylik funksiyasi).
 */
object MacVendorLookup {

    private val ouiMap: Map<String, String> = mapOf(
        // TP-Link
        "F4F26D" to "TP-Link", "50C7BF" to "TP-Link", "EC086B" to "TP-Link",
        "A42BB0" to "TP-Link", "D8474C" to "TP-Link", "C46E1F" to "TP-Link",
        // Xiaomi / Mi
        "F0B4D2" to "Xiaomi", "78111C" to "Xiaomi", "34CE00" to "Xiaomi",
        "64B473" to "Xiaomi", "7CB27D" to "Xiaomi",
        // Huawei
        "48435A" to "Huawei", "00E0FC" to "Huawei", "F41F88" to "Huawei",
        "20F3A3" to "Huawei", "00664B" to "Huawei",
        // ASUS
        "1C872C" to "ASUS", "2C56DC" to "ASUS", "704D7B" to "ASUS",
        "AC220B" to "ASUS", "D017C2" to "ASUS",
        // Netgear
        "204E7F" to "Netgear", "A040A0" to "Netgear", "84D4C4" to "Netgear",
        "44D9E7" to "Netgear",
        // D-Link
        "1C7EE5" to "D-Link", "C4A81D" to "D-Link", "78321B" to "D-Link",
        "B0C554" to "D-Link",
        // MikroTik
        "4C5E0C" to "MikroTik", "6C3B6B" to "MikroTik", "648099" to "MikroTik",
        "B869F4" to "MikroTik", "CC2DE0" to "MikroTik",
        // Ubiquiti
        "245A4C" to "Ubiquiti Networks", "802AA8" to "Ubiquiti Networks",
        "F09FC2" to "Ubiquiti Networks", "DC9FDB" to "Ubiquiti Networks",
        // Cisco
        "0022BD" to "Cisco", "001B54" to "Cisco", "70DB98" to "Cisco",
        // Huawei ONT / GPON (keng tarqalgan O'zbekistonda)
        "601896" to "Huawei (ONT)", "4090E1" to "Huawei (ONT)",
        // ZTE
        "D4CA6D" to "ZTE", "9829A6" to "ZTE", "78A2A0" to "ZTE",
        // Apple (AirPort/personal hotspot)
        "F0B479" to "Apple", "A4C361" to "Apple", "3C0754" to "Apple",
        "6C4008" to "Apple", "F02475" to "Apple",
        // Samsung (hotspot)
        "8C7712" to "Samsung", "5C0A5B" to "Samsung", "347E5C" to "Samsung",
        // Tenda
        "C83A35" to "Tenda", "50329D" to "Tenda", "00B00C" to "Tenda",
        // Ruijie / Fiberhome (O'zbekiston ISP uskunalari)
        "2C4D54" to "FiberHome", "F8A2D6" to "FiberHome",
        "245F7C" to "Ruijie", "8C3BAD" to "Ruijie",
        // Nokia (ONT)
        "84A783" to "Nokia", "701DEC" to "Nokia",
        // Zyxel
        "B0B2DC" to "Zyxel", "6CB0CE" to "Zyxel",
        // Xiaomi router range
        "289E9C" to "Xiaomi (Router)"
    )

    /**
     * Berilgan MAC/BSSID uchun ishlab chiqaruvchi nomini qaytaradi.
     */
    fun lookup(bssid: String): String {
        val normalized = bssid.uppercase().replace(":", "").replace("-", "")
        if (normalized.length < 6) return "Noma'lum ishlab chiqaruvchi"

        // Locally administered address (randomized MAC) tekshiruvi:
        // ikkinchi hex hona (bit pattern) 2, 6, A yoki E bo'lsa - tasodifiy MAC
        val secondChar = normalized[1]
        if (secondChar in "26AE") {
            return "Tasodifiy MAC (aniqlab bo'lmaydi)"
        }

        val prefix = normalized.substring(0, 6)
        return ouiMap[prefix] ?: "Noma'lum ishlab chiqaruvchi"
    }
}
