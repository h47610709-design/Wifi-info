package com.wifiinfopro.app.ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.R
import com.wifiinfopro.app.data.FrequencyBand
import com.wifiinfopro.app.ui.components.ChannelOccupancyChart
import com.wifiinfopro.app.ui.components.PermissionGate
import com.wifiinfopro.app.viewmodel.WifiViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChannelGraphScreen(viewModel: WifiViewModel) {
    val uiState by viewModel.uiState.collectAsState()

    PermissionGate {
        Scaffold(
            topBar = { TopAppBar(title = { Text(stringResource(R.string.tab_channels)) }) }
        ) { padding ->
            Column(
                modifier = Modifier
                    .padding(padding)
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp)
            ) {
                Text(
                    text = stringResource(R.string.channel_occupancy_title),
                    style = MaterialTheme.typography.titleMedium
                )
                ChannelOccupancyChart(
                    networks = uiState.networks.filter { it.band == FrequencyBand.GHZ_2_4 },
                    channels = (1..14).toList(),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                        .padding(bottom = 24.dp)
                )

                Text(
                    text = stringResource(R.string.channel_occupancy_5ghz),
                    style = MaterialTheme.typography.titleMedium
                )
                ChannelOccupancyChart(
                    networks = uiState.networks.filter { it.band == FrequencyBand.GHZ_5 },
                    channels = listOf(36, 40, 44, 48, 52, 56, 60, 64, 100, 104, 108, 112, 116, 120, 124, 128, 132, 136, 140, 144, 149, 153, 157, 161, 165),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(200.dp)
                )
            }
        }
    }
}
