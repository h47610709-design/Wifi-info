package com.wifiinfopro.app.ui.theme

import androidx.compose.ui.graphics.Color

// Asosiy brend ranglar - zamonaviy Wi-Fi/tex mavzusi (moviy-binafsha gradient)
val PrimaryBlue = Color(0xFF3D7BFF)
val PrimaryBlueDark = Color(0xFF2952CC)
val AccentViolet = Color(0xFF7C4DFF)
val AccentCyan = Color(0xFF00E5CC)

val SignalExcellent = Color(0xFF2ECC71)
val SignalGood = Color(0xFF8BC34A)
val SignalMedium = Color(0xFFFFC107)
val SignalWeak = Color(0xFFFF7043)
val SignalVeryWeak = Color(0xFFE53935)

val LightBackground = Color(0xFFF6F8FC)
val LightSurface = Color(0xFFFFFFFF)
val LightOnSurface = Color(0xFF1A1C1E)

val DarkBackground = Color(0xFF0E1013)
val DarkSurface = Color(0xFF191C20)
val DarkOnSurface = Color(0xFFE3E2E6)
