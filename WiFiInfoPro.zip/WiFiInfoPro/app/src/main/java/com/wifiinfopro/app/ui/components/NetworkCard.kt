package com.wifiinfopro.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.SignalWifi4Bar
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.wifiinfopro.app.data.SecurityType
import com.wifiinfopro.app.data.WifiNetworkInfo
import com.wifiinfopro.app.ui.theme.signalColor

@Composable
fun NetworkCard(
    network: WifiNetworkInfo,
    isStrongest: Boolean,
    onClick: () -> Unit
) {
    val animatedSignal by animateFloatAsState(
        targetValue = network.signalPercent / 100f,
        animationSpec = tween(600),
        label = "signal"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .clickable { onClick() }
            .let {
                if (isStrongest) it.border(2.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(20.dp)) else it
            },
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SignalRing(percent = animatedSignal, color = signalColor(network.rssiDbm))

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(start = 14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = network.ssid,
                        style = MaterialTheme.typography.titleMedium,
                        maxLines = 1
                    )
                    if (isStrongest) {
                        Icon(
                            imageVector = Icons.Filled.Star,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier
                                .padding(start = 6.dp)
                                .size(16.dp)
                        )
                    }
                }
                Text(
                    text = "${network.vendor} • ${network.band.label()} • ${network.channel}-kanal",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                    maxLines = 1
                )
                Row(
                    modifier = Modifier.padding(top = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SecurityBadge(network.securityType)
                    Badge(text = network.standard.label)
                }
            }

            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = "${network.rssiDbm} dBm",
                    style = MaterialTheme.typography.bodyMedium,
                    color = signalColor(network.rssiDbm)
                )
                Text(
                    text = "${network.signalPercent}%",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        }
    }
}

@Composable
private fun SignalRing(percent: Float, color: Color) {
    Box(
        modifier = Modifier.size(46.dp),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.foundation.Canvas(modifier = Modifier.size(46.dp)) {
            drawArc(
                color = color.copy(alpha = 0.15f),
                startAngle = -90f,
                sweepAngle = 360f,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 6.dp.toPx())
            )
            drawArc(
                color = color,
                startAngle = -90f,
                sweepAngle = 360f * percent,
                useCenter = false,
                style = androidx.compose.ui.graphics.drawscope.Stroke(
                    width = 6.dp.toPx(),
                    cap = androidx.compose.ui.graphics.StrokeCap.Round
                )
            )
        }
        Icon(
            imageVector = Icons.Filled.SignalWifi4Bar,
            contentDescription = null,
            tint = color,
            modifier = Modifier.size(20.dp)
        )
    }
}

@Composable
fun SecurityBadge(type: SecurityType) {
    val (label, color) = when (type) {
        SecurityType.OPEN -> "Open" to Color(0xFFE53935)
        SecurityType.WEP -> "WEP" to Color(0xFFFF7043)
        SecurityType.WPA -> "WPA" to Color(0xFFFFC107)
        SecurityType.WPA2 -> "WPA2" to Color(0xFF8BC34A)
        SecurityType.WPA3 -> "WPA3" to Color(0xFF2ECC71)
        SecurityType.WPA2_WPA3 -> "WPA2/3" to Color(0xFF2ECC71)
        SecurityType.ENTERPRISE -> "Enterprise" to Color(0xFF3D7BFF)
        SecurityType.UNKNOWN -> "?" to Color.Gray
    }
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(color.copy(alpha = 0.15f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (type == SecurityType.OPEN) Icons.Filled.LockOpen else Icons.Filled.Lock,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(11.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = color,
                modifier = Modifier.padding(start = 3.dp)
            )
        }
    }
}

@Composable
fun Badge(text: String) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.08f))
            .padding(horizontal = 8.dp, vertical = 3.dp)
    ) {
        Text(text = text, style = MaterialTheme.typography.labelSmall)
    }
}

private fun com.wifiinfopro.app.data.FrequencyBand.label(): String = when (this) {
    com.wifiinfopro.app.data.FrequencyBand.GHZ_2_4 -> "2.4 GHz"
    com.wifiinfopro.app.data.FrequencyBand.GHZ_5 -> "5 GHz"
    com.wifiinfopro.app.data.FrequencyBand.GHZ_6 -> "6 GHz"
    com.wifiinfopro.app.data.FrequencyBand.UNKNOWN -> "?"
}
